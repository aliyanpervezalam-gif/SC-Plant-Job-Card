SC - Corrugation Job Card System (HTML + CSS + JavaScript)

Chalane ka tareeka: index.html par double-click karo (Chrome / Edge). Kuch install nahi karna.
Files: index.html, style.css, script.js (teeno ek hi folder me rahein).

Data isi browser me save hota hai. Dashboard par "Backup data" se file save kar lo.
Print / PDF: job card kholo -> Print ya Save as PDF.
Export Excel: .xls file banti hai (Excel me live formulas ke saath).
