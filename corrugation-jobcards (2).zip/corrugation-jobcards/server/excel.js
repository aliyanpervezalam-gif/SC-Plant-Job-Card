import ExcelJS from 'exceljs';
import { toNum } from '../shared/calc.js';

// Rebuilds the original Excel layout with LIVE formulas (same cells as Job_Card_JS2751.xlsx).
export async function jobToWorkbook(job) {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Job Card', { pageSetup: { paperSize: 9, orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 1 } });
  [9, 11, 14, 12, 11, 13, 15, 16, 16, 14].forEach((w, i) => (ws.getColumn(i + 1).width = w));
  const bold = { bold: true }, edge = { style: 'thin' }, box = { top: edge, left: edge, bottom: edge, right: edge };
  const IN = 'FFFFF2CC', CALC = 'FFE2EFDA';
  const put = (a, v, o = {}) => { const c = ws.getCell(a); c.value = v; c.border = box; if (o.b) c.font = bold;
    if (o.fill) c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: o.fill } }; return c; };
  ws.mergeCells('A1:J1'); put('A1', 'SC - CORRUGATION PLANT - JOB CARD', { b: true }).alignment = { horizontal: 'center' };
  put('A3', 'Date', { b: true }); ws.mergeCells('B3:C3'); put('B3', job.date, { fill: IN });
  put('D3', 'SC', { b: true }); ws.mergeCells('E3:F3'); put('E3', job.customerCode, { fill: IN });
  put('G3', 'Job Nature', { b: true }); ws.mergeCells('H3:J3'); put('H3', job.nature, { fill: IN });
  put('A4', 'JS #', { b: true }); ws.mergeCells('B4:C4'); put('B4', Number(job.jobNo) || job.jobNo, { fill: IN });
  put('D4', 'Customer', { b: true }); ws.mergeCells('E4:G4'); put('E4', job.customerName, { fill: IN });
  put('H4', 'Plant', { b: true }); ws.mergeCells('I4:J4'); put('I4', job.plant.toUpperCase(), { fill: IN });
  [['A6', 'C (inch)'], ['C6', 'R (inch)'], ['E6', 'Ups'], ['G6', 'Pcs/Ctn'], ['I6', 'Sheet Qty']].forEach(([a, t]) => put(a, t, { b: true }));
  [['B6', job.cInch], ['D6', job.rInch], ['F6', job.ups], ['H6', job.pcs], ['J6', job.sheetQty]].forEach(([a, v]) => put(a, toNum(v), { fill: IN }));
  ws.mergeCells('A7:A8'); put('A7', 'Carton Size', { b: true });
  [['B7', 'L (mm)'], ['C7', 'W (mm)'], ['D7', 'H (mm)'], ['E7', 'Flap Size']].forEach(([a, t]) => put(a, t, { b: true }));
  ws.mergeCells('F7:G7'); put('F7', 'Note', { b: true }); put('I7', 'Ctn Qty', { b: true });
  put('B8', toNum(job.lengthMm), { fill: IN }); put('C8', toNum(job.widthMm), { fill: IN }); put('D8', toNum(job.heightMm), { fill: IN }); put('E8', job.flap, { fill: IN });
  ws.mergeCells('F8:G8'); put('F8', job.notes, { fill: IN });
  put('J7', { formula: 'J6*F6*H6' }, { fill: CALC }); put('I8', 'Wastage %', { b: true }); put('J8', toNum(job.wastage) || 0, { fill: IN });
  ['No', 'Code', 'Material', 'Size (inch)', 'GSM', 'Take-up Factor', 'Open Balance (kg)', 'Required Weight (kg)', 'Close Balance (kg)', 'Status']
    .forEach((t, i) => put(String.fromCharCode(65 + i) + '10', t, { b: true, fill: 'FFD9D9D9' }));
  const first = 11, last = first + job.lines.length - 1;
  job.lines.forEach((l, i) => { const r = first + i;
    put(`A${r}`, i + 1); put(`B${r}`, l.code); put(`C${r}`, l.material); put(`D${r}`, toNum(l.reel), { fill: IN }); put(`E${r}`, toNum(l.gsm), { fill: IN });
    put(`F${r}`, toNum(l.takeUp), { fill: IN }); put(`G${r}`, toNum(l.open), { fill: IN });
    put(`H${r}`, { formula: `IF(OR($B$6="",D${r}="",E${r}="",F${r}=""),"",ROUND($B$6*0.0254*D${r}*0.0254*E${r}*$J$6*F${r}*(1+$J$8/100)/1000,1))` }, { fill: CALC });
    put(`I${r}`, { formula: `IF(OR(G${r}="",H${r}=""),"",ROUND(G${r}-H${r},1))` }, { fill: CALC });
    put(`J${r}`, { formula: `IF(I${r}="","",IF(I${r}<0,"SHORT","OK"))` }, { fill: CALC }); });
  const t = last + 1; ws.mergeCells(`A${t}:F${t}`); put(`A${t}`, 'TOTAL', { b: true });
  ['G', 'H', 'I'].forEach((c) => put(`${c}${t}`, { formula: `SUM(${c}${first}:${c}${last})` }, { b: true, fill: CALC }));
  ws.mergeCells(`A${t + 2}:J${t + 2}`);
  put(`A${t + 2}`, 'Required Weight = C x 0.0254 x Size x 0.0254 x GSM x Sheet Qty x Take-up x (1 + Wastage%/100) / 1000.  Close Balance = Open Balance - Required Weight.');
  return wb;
}
