import express from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import * as S from './service.js';
import { jobToWorkbook } from './excel.js';

const app = express();
app.use(cors()); app.use(express.json({ limit: '1mb' }));
const wrap = (fn) => (req, res, next) => { try { Promise.resolve(fn(req, res)).catch(next); } catch (e) { next(e); } };
const notFound = () => new S.HttpError(404, 'Job card not found.');

app.get('/api/dashboard', wrap((q, r) => r.json(S.dashboard())));
app.get('/api/next-job-no', wrap((q, r) => r.json({ jobNo: S.nextJobNo() })));
app.get('/api/job-no/check', wrap((q, r) => r.json({ exists: S.jobNoExists(q.query.jobNo || '', q.query.exclude) })));
app.get('/api/jobs', wrap((q, r) => r.json(S.listJobs(q.query))));
app.post('/api/jobs', wrap((q, r) => r.status(201).json(S.createJob(q.body))));
app.get('/api/jobs/:id', wrap((q, r) => { const j = S.getJob(+q.params.id); if (!j) throw notFound(); r.json(j); }));
app.put('/api/jobs/:id', wrap((q, r) => r.json(S.updateJob(+q.params.id, q.body))));
app.delete('/api/jobs/:id', wrap((q, r) => { S.deleteJob(+q.params.id); r.json({ ok: true }); }));
app.post('/api/jobs/:id/duplicate', wrap((q, r) => r.status(201).json(S.duplicateJob(+q.params.id))));
app.get('/api/jobs/:id/history', wrap((q, r) => r.json(S.history(+q.params.id))));
app.get('/api/jobs/:id/excel', wrap(async (q, r) => {
  const j = S.getJob(+q.params.id); if (!j) throw notFound();
  const wb = await jobToWorkbook(j);
  r.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  r.setHeader('Content-Disposition', `attachment; filename="Job_Card_JS${j.jobNo}.xlsx"`);
  await wb.xlsx.write(r); r.end();
}));

const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'client', 'dist');
if (fs.existsSync(dist)) { app.use(express.static(dist)); app.get(/^\/(?!api).*/, (q, r) => r.sendFile(path.join(dist, 'index.html'))); }
app.use((e, q, r, n) => { if (!e.status) console.error(e); r.status(e.status || 500).json({ error: e.message, details: e.details }); });

S.seedIfEmpty();
const port = process.env.PORT || 3001;
app.listen(port, () => console.log(`Job card system running at http://localhost:${port}`));
