# SC – Corrugation Job Card Management System

React + Node/Express + SQLite. Formulas come from `Job_Card_JS2751.xlsx` and live in ONE file, `shared/calc.js`, used by both server and browser.

## Install and run (Node 18+; Node 22 recommended)
    npm run setup        # installs server and client packages
    npm run build        # builds the React app into client/dist
    npm start            # open http://localhost:3001
Development with hot reload: `npm run dev:server` and `npm run dev:client` (open http://localhost:5173).
Tests: `npm test`. The SQLite file is created at `server/data/jobcards.db` (back up this file). First start inserts your JS 2751 card.

## Folders
    shared/calc.js            all formulas + validation
    server/db.js              SQLite schema (customers, jobs, job_materials, job_history)
    server/service.js         save / edit / delete / duplicate / search / dashboard
    server/excel.js           Excel export with live formulas
    server/index.js           Express API
    client/src/App.jsx        dashboard, list, form, job card + print layout
    server/test/calc.test.js  tests using your Excel example

## Moving to PostgreSQL later
SQL is standard (INTEGER keys, REAL, TEXT). Replace `server/db.js` with a `pg` pool and make the `service.js` calls async.
