// Single source of truth for every Excel formula. Used by the server AND the React app.
export const PLY_ROWS = { '3 Ply': 3, '5 Ply': 5, '7 Ply': 7 };
export const PLANTS = Object.keys(PLY_ROWS);
export const r1 = (x) => Math.round((x + Number.EPSILON) * 10) / 10;
export const toNum = (v) => (v === '' || v == null || !Number.isFinite(Number(v)) ? null : Number(v));
export const defaultTakeUp = (material) => (/cmp|flut/i.test(material || '') ? 1.35 : 1.0);
export const blankLine = () => ({ code: '', material: '', reel: '', gsm: '', takeUp: '', open: '' });

// Excel J7: =J6*F6*H6
export const cartonQty = (j) => (toNum(j.sheetQty) || 0) * (toNum(j.ups) || 0) * (toNum(j.pcs) || 0);

// Excel H11: ROUND(C*0.0254*Size*0.0254*GSM*SheetQty*TakeUp*(1+Wastage/100)/1000, 1). null when any input is missing.
export function requiredWeight(job, l) {
  const c = toNum(job.cInch), reel = toNum(l.reel), gsm = toNum(l.gsm), tu = toNum(l.takeUp);
  if (c == null || reel == null || gsm == null || gsm <= 0 || tu == null) return null;
  const w = (toNum(job.wastage) || 0) / 100;
  return r1(c * 0.0254 * (reel * 0.0254) * gsm * (toNum(job.sheetQty) || 0) * tu * (1 + w) / 1000);
}

// Excel I11/J11. Missing stock is NEVER treated as 0: status says so.
export function lineCalc(job, l) {
  const req = requiredWeight(job, l), open = toNum(l.open);
  const close = open == null || req == null ? null : r1(open - req);
  const used = ['code', 'material', 'reel', 'gsm', 'open'].some((k) => String(l[k] ?? '') !== '');
  let status = '';
  if (used) status = req == null ? 'GSM MISSING' : open == null ? 'NO STOCK DATA' : close < 0 ? 'SHORT' : 'OK';
  return { required: req, close, status, used };
}

// Excel row 16 totals (sum of the rounded line values).
export function jobCalc(job) {
  const lines = (job.lines || []).map((l) => lineCalc(job, l));
  const sum = (k) => r1(lines.reduce((a, x) => a + (x[k] || 0), 0));
  const open = r1((job.lines || []).reduce((a, l) => a + (toNum(l.open) || 0), 0));
  const count = (s) => lines.filter((x) => x.status === s).length;
  return {
    cartonQty: cartonQty(job), lines, totalOpen: open, totalRequired: sum('required'), totalClose: sum('close'),
    short: count('SHORT'), gsmMissing: count('GSM MISSING'), noStock: count('NO STOCK DATA'),
    overall: count('SHORT') ? 'SHORT' : count('GSM MISSING') ? 'GSM MISSING' : count('NO STOCK DATA') ? 'NO STOCK DATA' : lines.some((x) => x.used) ? 'OK' : '',
  };
}

export function validateJob(job) {
  const e = [];
  if (!String(job.jobNo ?? '').trim()) e.push('Job number (JS #) is required.');
  if (!job.date) e.push('Date is required.');
  if (!String(job.customerName ?? '').trim()) e.push('Customer name is required.');
  if (!PLANTS.includes(job.plant)) e.push('Plant must be 3 Ply, 5 Ply or 7 Ply.');
  const nn = { 'C (inch)': job.cInch, 'R (inch)': job.rInch, Ups: job.ups, 'Pcs/Ctn': job.pcs, 'Sheet Qty': job.sheetQty, 'Wastage %': job.wastage, Length: job.lengthMm, Width: job.widthMm, Height: job.heightMm };
  for (const [k, v] of Object.entries(nn)) { if (String(v ?? '') !== '' && (toNum(v) == null || toNum(v) < 0)) e.push(`${k} must be a number, 0 or more.`); }
  (job.lines || []).forEach((l, i) => ['reel', 'gsm', 'takeUp', 'open'].forEach((k) => {
    if (String(l[k] ?? '') !== '' && (toNum(l[k]) == null || toNum(l[k]) < 0)) e.push(`Row ${i + 1}: ${k} must be a number, 0 or more.`);
  }));
  return e;
}
