import React, { useEffect, useState } from 'react';
import { api } from './api.js';
import { PLANTS, PLY_ROWS, blankLine, defaultTakeUp, jobCalc, validateJob } from '../../shared/calc.js';

const fmt = (n) => (n == null || n === '' ? '—' : Number(n).toLocaleString('en-US', { maximumFractionDigits: 1 }));
const dmy = (d) => (d ? d.split('-').reverse().join('/') : '');
const today = () => new Date().toISOString().slice(0, 10);
const Pill = ({ s }) => !s ? null : <span className={'pill ' + (s === 'OK' ? 'ok' : s === 'SHORT' ? 'bad' : 'warn')}>{s}</span>;

export default function App() {
  const [view, setView] = useState({ name: 'dash' });
  const go = (name, id) => setView({ name, id });
  const nav = [['dash', 'Dashboard'], ['list', 'Job cards'], ['form', 'New job card']];
  return (
    <div className="app">
      <nav className="no-print">
        <div className="brand">SC<small>Corrugation plant</small></div>
        {nav.map(([k, t]) => <button key={k} className={view.name === k && !(k === 'form' && view.id) ? 'on' : ''} onClick={() => go(k)}>{t}</button>)}
      </nav>
      <main>
        {view.name === 'dash' && <Dashboard go={go} />}
        {view.name === 'list' && <List go={go} />}
        {view.name === 'form' && <Form key={view.id || 'new'} id={view.id} go={go} />}
        {view.name === 'view' && <View key={view.id} id={view.id} go={go} />}
      </main>
    </div>
  );
}

function Dashboard({ go }) {
  const [d, setD] = useState(null), [err, setErr] = useState('');
  useEffect(() => { api.dashboard().then(setD).catch((e) => setErr(e.message)); }, []);
  if (err) return <p className="ban bad">{err}</p>;
  if (!d) return <p>Loading…</p>;
  const max = Math.max(1, ...d.byCustomer.map((c) => c.kg));
  const K = ({ v, l, bad }) => <div className={'kpi' + (bad ? ' bad' : '')}><b>{v}</b><span>{l}</span></div>;
  return (<>
    <div className="bar"><h1>Dashboard</h1><div className="sp" /><button className="p" onClick={() => go('form')}>New job card</button></div>
    <div className="kpis">
      <K v={d.totalJobs} l="Total job cards" /><K v={fmt(d.totalSheets)} l="Total sheet quantity" /><K v={fmt(d.totalCartons)} l="Total carton quantity" />
      <K v={fmt(d.totalRequiredKg) + ' kg'} l="Total required reel weight" /><K v={fmt(d.totalStockKg) + ' kg'} l="Total available reel stock" />
      <K v={d.alerts.length} l="Short stock alerts" bad={d.alerts.length > 0} />
    </div>
    {d.alerts.length > 0 && <div className="ban bad">Short stock: {d.alerts.map((a) => <button key={a.id} className="lnk" onClick={() => go('view', a.id)}>JS {a.jobNo} ({a.shortLines} reel{a.shortLines > 1 ? 's' : ''})</button>)}</div>}
    {d.incompleteJobs > 0 && <div className="ban warn">{d.incompleteJobs} job card(s) have missing GSM or stock figures, so their weights are incomplete and not counted as zero stock.</div>}
    <div className="card"><h2>Required reel weight by customer</h2>
      {d.byCustomer.every((c) => !c.kg) ? <p className="muted">Enter GSM on job cards to see required weight.</p> :
        <svg viewBox="0 0 600 190" className="chart" role="img" aria-label="Required weight by customer">
          {d.byCustomer.map((c, i) => <g key={c.name} transform={`translate(0 ${i * 30})`}>
            <text x="0" y="16" fontSize="12" fill="currentColor">{c.name.slice(0, 26)}</text>
            <rect x="200" y="3" width={Math.max(2, (c.kg / max) * 330)} height="18" fill="var(--kraft)" />
            <text x={206 + (c.kg / max) * 330} y="17" fontSize="12" fill="currentColor">{fmt(c.kg)} kg</text></g>)}
        </svg>}
    </div>
    <div className="card"><h2>Recent job cards</h2><JobTable jobs={d.recent} go={go} /></div>
  </>);
}

function JobTable({ jobs, go, actions }) {
  if (!jobs.length) return <p className="empty">No job cards found.</p>;
  return <div className="tw"><table><thead><tr><th>JS #</th><th>Date</th><th>Customer</th><th>Plant</th><th className="n">Sheets</th><th className="n">Cartons</th><th className="n">Required kg</th><th>Stock check</th><th>Status</th>{actions && <th />}</tr></thead>
    <tbody>{jobs.map((j) => <tr key={j.id} className="click" onClick={() => go('view', j.id)}>
      <td><b>{j.jobNo}</b></td><td>{dmy(j.date)}</td><td>{j.customerName}</td><td>{j.plant}</td><td className="n">{fmt(j.sheetQty)}</td>
      <td className="n">{fmt(j.calc.cartonQty)}</td><td className="n">{j.calc.lines.some((l) => l.required != null) ? fmt(j.calc.totalRequired) : '—'}</td>
      <td><Pill s={j.calc.overall} /></td><td>{j.status}</td>{actions && <td onClick={(e) => e.stopPropagation()}>{actions(j)}</td>}</tr>)}</tbody></table></div>;
}

function List({ go }) {
  const [f, setF] = useState({ q: '', from: '', to: '' }), [jobs, setJobs] = useState([]), [msg, setMsg] = useState('');
  const load = () => api.list(f).then(setJobs).catch((e) => setMsg(e.message));
  useEffect(() => { load(); }, [f.q, f.from, f.to]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const del = async (j) => { if (window.confirm(`Delete job card JS ${j.jobNo}? Its data is kept in history, but the card will be removed.`)) { await api.remove(j.id); load(); } };
  const dup = async (j) => { const n = await api.duplicate(j.id); go('form', n.id); };
  return (<>
    <div className="bar"><h1>Job cards</h1><div className="sp" /><button className="p" onClick={() => go('form')}>New job card</button></div>
    {msg && <p className="ban bad">{msg}</p>}
    <div className="card"><div className="grid">
      <label className="f"><span>Search job number or customer</span><input value={f.q} onChange={set('q')} /></label>
      <label className="f"><span>Date from</span><input type="date" value={f.from} onChange={set('from')} /></label>
      <label className="f"><span>Date to</span><input type="date" value={f.to} onChange={set('to')} /></label></div>
      <JobTable jobs={jobs} go={go} actions={(j) => <>
        <button onClick={() => go('form', j.id)}>Edit</button> <button onClick={() => dup(j)}>Duplicate</button> <button className="d" onClick={() => del(j)}>Delete</button></>} />
    </div></>);
}

const newJob = (jobNo) => ({ jobNo, date: today(), customerName: '', customerCode: '', nature: '', plant: '3 Ply', cInch: '', rInch: '', ups: 1, pcs: 1, sheetQty: '',
  lengthMm: '', widthMm: '', heightMm: '', flap: '', notes: '', wastage: 0, status: 'Draft', lines: Array.from({ length: 3 }, blankLine) });

function Form({ id, go }) {
  const [job, setJob] = useState(null), [errs, setErrs] = useState([]), [dupNo, setDupNo] = useState(false), [saving, setSaving] = useState(false);
  useEffect(() => { (id ? api.get(id) : api.nextNo().then((r) => newJob(r.jobNo))).then(setJob).catch((e) => setErrs([e.message])); }, [id]);
  useEffect(() => { if (job?.jobNo) api.noExists(job.jobNo, id).then((r) => setDupNo(r.exists)).catch(() => {}); }, [job?.jobNo]);
  if (!job) return <p>Loading…</p>;
  const c = jobCalc(job);
  const set = (k) => (e) => setJob({ ...job, [k]: e.target.value });
  const num = (k, extra = {}) => <input type="number" min="0" step="any" inputMode="decimal" value={job[k]} onChange={set(k)} {...extra} />;
  const setPlant = (e) => { const want = PLY_ROWS[e.target.value]; let lines = [...job.lines];
    while (lines.length < want) lines.push(blankLine());
    while (lines.length > want && !Object.values(lines[lines.length - 1]).some((v) => v !== '')) lines.pop();
    setJob({ ...job, plant: e.target.value, lines }); };
  const setLine = (i, k, v) => { const lines = job.lines.map((l, x) => (x === i ? { ...l, [k]: v } : l));
    if (k === 'material' && (lines[i].takeUp === '' || lines[i].takeUp === defaultTakeUp(job.lines[i].material))) lines[i].takeUp = v ? defaultTakeUp(v) : '';
    setJob({ ...job, lines }); };
  const save = async () => {
    const e = validateJob(job); if (dupNo) e.push(`Job number ${job.jobNo} already exists.`);
    if (e.length) return setErrs(e);
    setSaving(true); try { const s = id ? await api.update(id, job) : await api.create(job); go('view', s.id); } catch (x) { setErrs([x.message, ...(x.details || [])]); setSaving(false); }
  };
  return (<>
    <div className="bar"><h1>{id ? `Edit job card JS ${job.jobNo}` : 'New job card'}</h1><div className="sp" /><button onClick={() => go('list')}>Cancel</button><button className="p" disabled={saving} onClick={save}>Save job card</button></div>
    {errs.length > 0 && <div className="ban bad">{errs.map((x, i) => <div key={i}>{x}</div>)}</div>}
    <div className="card"><h2>Job information</h2><div className="grid">
      <label className="f"><span>Date</span><input type="date" value={job.date} onChange={set('date')} /></label>
      <label className="f"><span>Job number (JS #)</span><input value={job.jobNo} onChange={set('jobNo')} />{dupNo && <em className="bad-t">Already used</em>}</label>
      <label className="f"><span>Customer name</span><input value={job.customerName} onChange={set('customerName')} /></label>
      <label className="f"><span>Customer code (SC)</span><input value={job.customerCode} onChange={set('customerCode')} /></label>
      <label className="f"><span>Job nature</span><input value={job.nature} onChange={set('nature')} /></label>
      <label className="f"><span>Plant</span><select value={job.plant} onChange={setPlant}>{PLANTS.map((p) => <option key={p}>{p}</option>)}</select></label></div></div>
    <div className="card"><h2>Carton details</h2><div className="grid">
      <label className="f"><span>C (inch)</span>{num('cInch')}</label><label className="f"><span>R (inch)</span>{num('rInch')}</label>
      <label className="f"><span>Ups</span>{num('ups')}</label><label className="f"><span>Pcs/Ctn</span>{num('pcs')}</label>
      <label className="f"><span>Sheet qty</span>{num('sheetQty')}</label><label className="f"><span>Wastage (%)</span>{num('wastage')}</label>
      <label className="f"><span>Carton qty (automatic)</span><div className="calc">{fmt(c.cartonQty)}</div></label></div>
      <h3>Carton size</h3><div className="grid">
        <label className="f"><span>Length (mm)</span>{num('lengthMm')}</label><label className="f"><span>Width (mm)</span>{num('widthMm')}</label><label className="f"><span>Height (mm)</span>{num('heightMm')}</label>
        <label className="f"><span>Flap size</span><input value={job.flap} onChange={set('flap')} /></label>
        <label className="f"><span>Notes</span><input value={job.notes} onChange={set('notes')} /></label></div></div>
    <div className="card"><div className="bar"><h2>Reel / paper material</h2><div className="sp" /><button onClick={() => setJob({ ...job, lines: [...job.lines, blankLine()] })}>Add row</button></div>
      {c.short > 0 && <div className="ban bad">{c.short} reel(s) are short. Available stock is not enough.</div>}
      {c.gsmMissing > 0 && <div className="ban warn">Enter GSM on every used row. Required weight is not calculated without it.</div>}
      {c.noStock > 0 && <div className="ban warn">Open balance is blank on {c.noStock} row(s). Blank stock is not treated as zero, so enter the balance to check it.</div>}
      <div className="tw"><table><thead><tr><th>No.</th><th>Code</th><th>Material</th><th>Reel size (inch)</th><th>GSM</th><th>Take-up</th><th>Open balance (kg)</th><th className="n">Required (kg)</th><th className="n">Close balance (kg)</th><th>Status</th><th /></tr></thead>
        <tbody>{job.lines.map((l, i) => <tr key={i}><td>{i + 1}</td>
          <td><input value={l.code} onChange={(e) => setLine(i, 'code', e.target.value)} /></td>
          <td><input list="mats" value={l.material} onChange={(e) => setLine(i, 'material', e.target.value)} /></td>
          {['reel', 'gsm', 'takeUp', 'open'].map((k) => <td key={k}><input type="number" min="0" step="any" inputMode="decimal" value={l[k]} onChange={(e) => setLine(i, k, e.target.value)} /></td>)}
          <td className="n"><div className="calc">{fmt(c.lines[i].required)}</div></td><td className="n"><div className="calc">{fmt(c.lines[i].close)}</div></td>
          <td><Pill s={c.lines[i].status} /></td><td><button className="d" aria-label={`Remove row ${i + 1}`} onClick={() => setJob({ ...job, lines: job.lines.filter((_, x) => x !== i) })}>×</button></td></tr>)}</tbody>
        <tfoot><tr><th colSpan="6">Total</th><th className="n">{fmt(c.totalOpen)}</th><th className="n">{fmt(c.totalRequired)}</th><th className="n">{fmt(c.totalClose)}</th><th colSpan="2" /></tr></tfoot></table></div>
      <datalist id="mats"><option>N Dubai</option><option>CMP</option><option>Kraft</option><option>Test Liner</option><option>White Top</option></datalist>
      <p className="muted">Take-up fills as 1.00 for liners and 1.35 for CMP / fluting. You can change it. Choosing 5 Ply or 7 Ply adds the matching rows.</p></div>
    <div className="bar"><button className="p" disabled={saving} onClick={save}>Save job card</button><button onClick={() => go('list')}>Cancel</button></div>
  </>);
}

function Sheet({ job }) {
  const c = job.calc || jobCalc(job);
  return (<div className="sheet">
    <div className="co">SC</div><h1>CORRUGATION PLANT – JOB CARD</h1>
    <table className="g"><tbody>
      <tr><th>Date</th><td>{dmy(job.date)}</td><th>SC</th><td>{job.customerCode}</td><th>Job nature</th><td colSpan="3">{job.nature}</td></tr>
      <tr><th>JS #</th><td>{job.jobNo}</td><th>Customer</th><td colSpan="3">{job.customerName}</td><th>Plant</th><td>{job.plant}</td></tr>
      <tr><th>C (inch)</th><td>{job.cInch}</td><th>R (inch)</th><td>{job.rInch}</td><th>Ups</th><td>{job.ups}</td><th>Pcs/Ctn</th><td>{job.pcs}</td></tr>
      <tr><th>Sheet qty</th><td>{fmt(job.sheetQty)}</td><th>Ctn qty</th><td><b>{fmt(c.cartonQty)}</b></td><th>Wastage %</th><td>{job.wastage}</td><th>Carton size</th><td>{job.lengthMm} × {job.widthMm} × {job.heightMm} mm</td></tr>
      <tr><th>Flap</th><td>{job.flap}</td><th>Note</th><td colSpan="5">{job.notes}</td></tr></tbody></table>
    <table className="m"><thead><tr><th>No</th><th>Code</th><th>Material</th><th>Size (inch)</th><th>GSM</th><th>Take-up</th><th>Open bal. (kg)</th><th>Required (kg)</th><th>Close bal. (kg)</th><th>Status</th></tr></thead>
      <tbody>{job.lines.map((l, i) => <tr key={i} className={c.lines[i].status === 'SHORT' ? 'sh' : ''}><td>{i + 1}</td><td>{l.code}</td><td>{l.material}</td><td>{l.reel}</td><td>{l.gsm}</td><td>{l.takeUp}</td>
        <td>{l.open === '' ? '' : fmt(l.open)}</td><td>{c.lines[i].required == null ? '' : fmt(c.lines[i].required)}</td><td>{c.lines[i].close == null ? '' : fmt(c.lines[i].close)}</td><td>{c.lines[i].status}</td></tr>)}</tbody>
      <tfoot><tr><th colSpan="6">TOTAL</th><th>{fmt(c.totalOpen)}</th><th>{fmt(c.totalRequired)}</th><th>{fmt(c.totalClose)}</th><th /></tr></tfoot></table>
    <div className="sig">{['Prepared by', 'Production', 'Store', 'Approved by'].map((s) => <div key={s}>{s}</div>)}</div></div>);
}

function View({ id, go }) {
  const [job, setJob] = useState(null), [hist, setHist] = useState([]), [err, setErr] = useState('');
  useEffect(() => { api.get(id).then(setJob).catch((e) => setErr(e.message)); api.history(id).then(setHist).catch(() => {}); }, [id]);
  if (err) return <p className="ban bad">{err}</p>;
  if (!job) return <p>Loading…</p>;
  const dup = async () => { const n = await api.duplicate(id); go('form', n.id); };
  return (<>
    <div className="bar no-print"><button onClick={() => go('list')}>Back</button><div className="sp" />
      <button onClick={() => go('form', id)}>Edit</button><button onClick={dup}>Duplicate</button>
      <a className="btn" href={`/api/jobs/${id}/excel`}>Export Excel</a>
      <button onClick={() => window.print()} title="Choose 'Save as PDF' as the printer">Save as PDF</button><button className="p" onClick={() => window.print()}>Print</button></div>
    {job.calc.overall && job.calc.overall !== 'OK' && <div className={'ban no-print ' + (job.calc.short ? 'bad' : 'warn')}>Stock check: {job.calc.overall}</div>}
    <Sheet job={job} />
    <div className="card no-print"><h2>History</h2>{hist.map((h) => <div key={h.id} className="muted">{h.at} UTC · {h.action}</div>)}</div>
  </>);
}
